const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const multer=require('multer')


let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/profileimage')
    },
    filename:function(req,file,cb){
        cb(null, Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{fieldSize:4*1024*1024}
})





function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/')
    }
}


function handlerole(req,res,next){
    if(req.session.role=='suscribed'){
        next()
    }else{
        res.send('You do not a suscriber to see the details. Please take a suscribetions.')
    }
}


router.get('/',regc.loginpage)
router.get('/signup',regc.signuppage)
router.post('/signup',regc.registration)
router.post('/',regc.logincheck)
router.get('/forgotform',regc.forgotform)
router.post('/forgotform',regc.sendlink)
router.get('/forgotchangepasswordform/:email',regc.forgotpasswordchangeform)
router.post('/forgotchangepasswordform/:email',regc.changepassword)
router.get('/logout',regc.logout)
router.get('/emailactivelink/:email',regc.activelink)
router.get('/userprofiles',handlelogin,regc.usersprofiles)
router.get('/profileupdate',handlelogin,regc.profileupdateform)
router.post('/profileupdate',upload.single('img'),regc.userprofileupdate)
router.get('/singledetail/:id',handlerole,handlelogin,regc.singleprofiledetail)




module.exports=router