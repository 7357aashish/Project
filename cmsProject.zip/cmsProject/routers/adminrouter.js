const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const Reg = require('../models/reg')


function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/')
    }
}


router.get('/dashboard',regc.admindashboard)
router.get('/users',handlelogin,regc.allusers)
router.get('/userdelete/:id',regc.userdelete)
router.get('/activelink/:email',regc.adminactivelink)
router.get('/roleupdate/:id',handlelogin,regc.roleupdate)





module.exports=router