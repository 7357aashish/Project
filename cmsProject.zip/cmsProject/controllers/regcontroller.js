const Reg = require('../models/reg')
const bcrypt = require('bcrypt')
const nodemailer = require('nodemailer')



exports.loginpage = (req, res) => {
    try {
        res.render('login.ejs', { message: '' })
    } catch (error) {
        console.log(error)
    }
}


exports.signuppage = (req, res) => {
    try {
        res.render('signup.ejs', { message: '' })
    } catch (error) {
        console.log(error)
    }
}


exports.registration = async (req, res) => {
    const { email, pass } = req.body
    try {
        const convertpassword = await bcrypt.hash(pass, 10)
        const usercheck = await Reg.findOne({ email: email })
        if (usercheck == null) {
            const record = await new Reg({ email: email, password: convertpassword })
            record.save()
            let testAccount = await nodemailer.createTestAccount();

            let transporter = await nodemailer.createTransport({
                host: "smtp.gmail.com",
                port: 587,
                secure: false,
                auth: {
                    // TODO: replace `user` and `pass` values from <https://forwardemail.net>
                    user: 'officeaashish123@gmail.com',
                    pass: 'rkgdepcebzqdqigo'
                }
            });
            console.log("connected to gmail smtp server")
            let info = await transporter.sendMail({
                from: 'officeaashish123@gmail.com', // sender address
                to: email, // list of receivers
                subject: 'Email Verification Link-CMS Project', // Subject line
                text: 'Click On Below Link to Activate Your Account', // plain text body
                html: `<a href=http://localhost:5000/emailactivelink/${email}>Click to Active Account</a>`, // html body
            });
            console.log("Sent Link Email Id")
            res.render('signup.ejs', { message: 'Account has been registered successfully' })
        } else {
            res.render('signup.ejs', { message: 'Email is already registered' })
        }
    } catch (error) {
        console.log(error)
    }
}


exports.logincheck = async (req, res) => {
    try {
        const { email, pass } = req.body
        const record = await Reg.findOne({ email: email })
        if (record !== null) {
            passwordcheck = await bcrypt.compare(pass, record.password)
            if (passwordcheck) {
                req.session.isAuth = true
                req.session.loginname = email
                req.session.role = record.role
                if (record.email == 'admin@gmail.com' || record.email == 'admin1@gmail.com') {
                    res.redirect('/admin/dashboard')
                } else if (record.status == 'unverified') {
                    res.render('login.ejs', { message: 'Your email acoount is not verified. Please check email to verify it.' })
                } else {
                    res.redirect('/userprofiles')
                }
            } else {
                res.render('login.ejs', { message: 'Wrong Password' })
            }
        } else {
            res.render('login.ejs', { message: 'Wrong Username' })
        }
    } catch (error) {
        console.log(error)
    }
}


exports.forgotform = (req, res) => {
    try {
        res.render('forgotform.ejs', { message: '' })
    } catch (error) {
        console.log(error)
    }
}


exports.sendlink = async (req, res) => {
    try {
        const { email } = req.body
        const record = await Reg.findOne({ email: email })
        if (record == null) {
            res.render('forgotform.ejs', { message: 'Email is not registered' })
        } else {

            let testAccount = await nodemailer.createTestAccount();

            let transporter = await nodemailer.createTransport({
                host: "smtp.gmail.com",
                port: 587,
                secure: false,
                auth: {
                    // TODO: replace `user` and `pass` values from <https://forwardemail.net>
                    user: 'officeaashish123@gmail.com',
                    pass: 'rkgdepcebzqdqigo'
                }
            });
            console.log("connected to gmail smtp server")

            let info = await transporter.sendMail({
                from: 'officeaashish123@gmail.com', // sender address
                to: email, // list of receivers
                subject: 'Forgot Password Link-CMS Project', // Subject line
                text: 'Click On Below Click to Change Password', // plain text body
                html: `<a href=http://localhost:5000/forgotchangepasswordform/${email}>Click to change password</a>`, // html body
            });
            console.log("Sent Link Email Id")
            res.render('forgotform.ejs', { message: 'Link has been send. Please check your email' })
        }
    } catch (error) {
        console.log(error)
    }
}


exports.forgotpasswordchangeform = (req, res) => {
    try {
        const email = req.params.email
        res.render('forgotpasswordchangeform.ejs', { email })
    } catch (error) {
        console.log(error)
    }
}


exports.changepassword = async (req, res) => {
    try {
        const email = req.params.email
        const record = await Reg.findOne({ email: email })
        const id = record.id
        const { password } = req.body
        const newPass = await bcrypt.hash(password, 10)
        await Reg.findByIdAndUpdate(id, { password: newPass })
        res.render('forgotpasswordmessage.ejs')
    } catch (error) {
        console.log(error)
    }
}



exports.admindashboard = (req, res) => {
    try {
        const loginname = req.session.loginname
        res.render('admin/dashboard.ejs', { loginname })
    } catch (error) {
        console.log(error)
    }
}


exports.logout = (req, res) => {
    try {
        req.session.destroy()
        res.redirect('/')
    } catch (error) {
        console.log(error)
    }
}


exports.allusers = async (req, res) => {
    try {
        const loginname = req.session.loginname
        const record = await Reg.find()
        res.render('admin/users.ejs', { loginname, record })
    } catch (error) {
        console.log(error)
    }
}


exports.userdelete = async (req, res) => {
    try {
        const id = req.params.id
        await Reg.findByIdAndDelete(id)
        res.redirect('/admin/users')
    } catch (error) {
        console.log(error)
    }
}


exports.activelink = async (req, res) => {
    try {
        const email = req.params.email
        const record = await Reg.findOne({ email: email })
        const id = record.id
        let currentstatus = null
        await Reg.findByIdAndUpdate(id, { status: 'verified' })
        res.render('activelinkmessage.ejs', { message: '!!Your account has been active!!' })
    } catch (error) {
        console.log(error)
    }
}

exports.usersprofiles = async (req, res) => {
    try {
        const loginname = req.session.loginname
        const record = await Reg.find({ img: { $nin: ['default.jpg'] } })
        res.render('usersprofiles.ejs', { loginname, record })
    } catch (error) {
        console.log(error)
    }
}

exports.profileupdateform = async (req, res) => {
    try {
        const loginname = req.session.loginname
        const record = await Reg.findOne({ email: loginname })
        //console.log(record)
        res.render('profileupdateform.ejs', { loginname, record, message: '' })
    } catch (error) {
        console.log(error)
    }
}


exports.userprofileupdate = async (req, res) => {
    try {
        const { fname, lname, mobile, about } = req.body
        const loginname = req.session.loginname
        const record = await Reg.findOne({ email: loginname })
        const id = record.id
        if (req.file) {
            const filename = req.file.filename
            await Reg.findByIdAndUpdate(id, { firstName: fname, lastName: lname, mobile: mobile, desc: about, img: filename })
        } else {
            await Reg.findByIdAndUpdate(id, { firstName: fname, lastName: lname, mobile: mobile, desc: about })
        }
        //res.render('profileupdateform.ejs',{loginname,record,message:'Successfully Profile Has Been Updated'})
        res.redirect('/profileupdate')
    } catch (error) {
        console.log(error)
    }
}

exports.adminactivelink = async (req, res) => {
    try {
        const email = req.params.email
        const record = await Reg.findOne({ email: email })
        const id = record.id
        let currentstatus = null
        if (record.status == 'unverified') {
            currentstatus = 'verified'
        } else {
            currentstatus = 'unverified'
        }
        await Reg.findByIdAndUpdate(id, { status: currentstatus })
        res.redirect('/admin/users')
    } catch (error) {
        console.log(error)
    }
}


exports.singleprofiledetail = async (req, res) => {
    try {
        const id = req.params.id
        const loginname = req.session.loginname
        const record = await Reg.findById(id)
        res.render('singleprofiledetail.ejs', { loginname, record })
    } catch (error) {
        console.log(error)
    }
}

exports.roleupdate = async (req, res) => {
    try {
        const id = req.params.id
        const record = await Reg.findById(id)
        let currentrole = null
        if (record.role == 'suscribed') {
            currentrole = 'unsuscribed'
        } else {
            currentrole = 'suscribed'
        }
        await Reg.findByIdAndUpdate(id, { role: currentrole })
        res.redirect('/admin/users')
    } catch (error) {
        console.log(error)
    }
}