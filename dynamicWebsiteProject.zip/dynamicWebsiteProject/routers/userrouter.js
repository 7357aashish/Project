const router=require('express').Router()
const upload=require('../helper/multer')

const regc=require('../controllers/regcontroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const queryc=require('../controllers/querycontroller')


router.get('/:message',regc.userindexpage)

router.get('/banner',bannerc.userbannerdetails)

router.get('/servicedetails/:id',servicec.userservicedetails)

router.get('/testi/:message',testic.usertestiform)
router.post('/testi/i',upload.single('img'),testic.usertestinominal)

router.post('/i',queryc.userquery)



module.exports=router