const Query = require('../models/query')
const nodemailer = require('nodemailer')


exports.userquery = (req, res) => {
  try {
    const { email, query } = req.body
    const record = new Query({ email: email, query: query })
    record.save()
    //console.log(record)
    res.redirect('/Query Successfully Posted')
  } catch (error) {
    console.log(error)
  }
}


exports.adminqueryselection = async (req, res) => {
  try {
    const message = req.params.message
    const record = await Query.find()
    if (message !== 'i') {
      res.render('admin/query.ejs', { record, message })
    } else {
      res.render('admin/query.ejs', { record, message: '' })
    }
  } catch (error) {
    console.log(error)
  }
}

exports.adminreplyform = async (req, res) => {
  try {
    const id = req.params.id
    const record = await Query.findById(id)
    res.render('admin/queryreplyform.ejs', { record })
  } catch (error) {
    console.log(error)
  }
}

exports.adminqueryreply = async (req, res) => {
  try {
    const id = req.params.id
    const { qto, qfrom, qsubject, qbody } = req.body
    const path = req.file.path
    let testAccount = await nodemailer.createTestAccount();

    let transporter = await nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: {
        // TODO: replace `user` and `pass` values from <https://forwardemail.net>
        user: 'officeaashish123@gmail.com',
        pass: 'rkgdepcebzqdqigo'
      }
    });
    console.log("connected to gmail smtp server")
    let info = await transporter.sendMail({
      from: qfrom, // sender address
      to: qto, // list of receivers
      subject: qsubject, // Subject line
      text: qbody, // plain text body
      //html: "<b>Hello World?</b>"", // html body
      attachments: [{
        path: path
      }]
    });
    console.log("Send Email")
    await Query.findByIdAndUpdate(id, { status: 'replied' })
    res.redirect('/admin/query/Successfully Replied')
  }
  catch (error) {
    console.log(error)
  }
}


exports.adminquerydelete = async (req, res) => {
  try {
    const id = req.params.id
    await Query.findByIdAndDelete(id)
    res.redirect('/admin/query/Query Successfully Deleted')
  } catch (error) {
    console.log(error)
  }
}