const Testi = require('../models/testi')


exports.usertestiform = (req, res) => {
    try {
        const message = req.params.message
        if (message !== 'i') {
            res.render('testiform.ejs', { message })
        } else {
            res.render('testiform.ejs', { message: '' })
        }
    } catch (error) {
        console.log(error)
    }
}


exports.usertestinominal = (req, res) => {
    try {
        const { quotes, name } = req.body
        if (req.file) {
            const filename = req.file.filename
            const record = new Testi({ quotes: quotes, name: name, img: filename })
            record.save()
        } else {
            const record = new Testi({ quotes: quotes, name: name, img: 'default.png' })
            record.save()
        }
        res.redirect('/testi/Testinominal Successfully Posted')
    } catch (error) {
        console.log(error)
    }
}


exports.admintestiselection = async (req, res) => {
    try {
        const message = req.params.message
        const record = await Testi.find()
        const totalTesti = await Testi.count()
        const publish = await Testi.count({ status: 'publish' })
        const unpublish = await Testi.count({ status: 'unpublish' })
        if (message !== 'i') {
            res.render('admin/testi.ejs', { record, totalTesti, publish, unpublish, message })
        } else {
            res.render('admin/testi.ejs', { record, totalTesti, publish, unpublish, message: '' })
        }
    } catch (error) {
        console.log(error)
    }
}


exports.admintestistatusupdate = async (req, res) => {
    try {
        const id = req.params.id
        const record = await Testi.findById(id)
        let newstatus = null
        if (record.status == 'unpublish') {
            newstatus = 'publish'
        } else {
            newstatus = 'unpublish'
        }
        await Testi.findByIdAndUpdate(id, { status: newstatus })
        res.redirect('/admin/testi/Testinominal Status Successfull Updated')
    } catch (error) {
        console.log(error)
    }
}

exports.admintestidelete = async (req, res) => {
    try {
        const id = req.params.id
        await Testi.findByIdAndDelete(id)
        res.redirect('/admin/testi/Testinominal Successfull deleted')
    } catch (error) {
        console.log(error)
    }
}