const Reg = require('../models/reg')
const Banner = require('../models/banner')
const Service = require('../models/service')
const Testi = require('../models/testi')



exports.login = (req, res) => {
    res.render('admin/login.ejs')
}


exports.ligincheck = async (req, res) => {
    try {
        const { us, pass } = req.body
        const usercheck = await Reg.findOne({ username: us })
        if (usercheck !== null) {
            if (usercheck.password == pass) {
                res.redirect('/admin/dashboard')
            } else {
                res.redirect('/admin/')
            }
        } else {
            res.redirect('/admin/')
        }
    } catch (error) {
        console.log(error)
    }
}

exports.dashboard = (req, res) => {
    res.render('admin/dashboard.ejs')
}

exports.userindexpage = async (req, res) => {
    try {
        const message = req.params.message
        const bannerRecord = await Banner.findOne()
        const serviceRecord = await Service.find({ status: 'publish' })
        const testiRecord = await Testi.find({ status: 'publish' })
        if (message !== 'i') {
            res.render('index.ejs', { bannerRecord, serviceRecord, testiRecord, message })
        } else {
            res.render('index.ejs', { bannerRecord, serviceRecord, testiRecord, message: '' })
        }
    } catch (error) {
        console.log(error)
    }
}