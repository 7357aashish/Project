const Service = require('../models/service')


exports.adminserviceselection = async (req, res) => {
    try {
        const message = req.params.message
        const record = await Service.find().sort({ postedDate: -1 })
        const totalService = await Service.count()
        const publish = await Service.count({ status: 'publish' })
        const unpublish = await Service.count({ status: 'unpublish' })
        if (message !== 'i') {
            res.render('admin/service.ejs', { record, totalService, publish, unpublish, message })
        } else {
            res.render('admin/service.ejs', { record, totalService, publish, unpublish, message: '' })
        }
    } catch (error) {
        console.log(error)
    }
}

exports.adminserviceaddform = (req, res) => {
    res.render('admin/serviceform.ejs')
}

exports.adminserviceadd = (req, res) => {
    try {
        const { name, desc, ldesc } = req.body
        const filename = req.file.filename
        let currentDateTime = new Date()
        const record = new Service({ name: name, desc: desc, ldesc: ldesc, img: filename, postedDate: currentDateTime })
        record.save()
        res.redirect('/admin/service/Service Successfully Added')
    } catch (error) {
        console.log(error)
    }
}

exports.adminservicedelete = async (req, res) => {
    try {
        const id = req.params.id
        await Service.findByIdAndDelete(id)
        res.redirect('/admin/service/Service Successfully Deleted')
    } catch (error) {
        console.log(error)
    }
}

exports.adminservicestatusupdate = async (req, res) => {
    try {
        const id = req.params.id
        const record = await Service.findById(id)
        let currentstatus = null
        if (record.status == 'unpublish') {
            currentstatus = 'publish'
        } else {
            currentstatus = 'unpublish'
        }
        await Service.findByIdAndUpdate(id, { status: currentstatus })
        res.redirect('/admin/service/Service Status Successfully Updated')
    } catch (error) {
        console.log(error)
    }
}


exports.userservicedetails = async (req, res) => {
    try {
        const id = req.params.id
        const record = await Service.findById(id)
        res.render('servicedetails.ejs', { record })
    } catch (error) {
        console.log(error)
    }
}