const Banner = require('../models/banner')

exports.adminbannerselection = async (req, res) => {
    try {
        const message = req.params.message
        const record = await Banner.findOne()
        if (message !== 'i') {
            res.render('admin/banner.ejs', { record, message })
        } else {
            res.render('admin/banner.ejs', { record, message: '' })
        }
    } catch (error) {
        console.log(error)
    }
}

exports.adminbannerupdateform = async (req, res) => {
    try {
        const id = req.params.id
        const record = await Banner.findById(id)
        res.render('admin/bannerform.ejs', { record })
    } catch (error) {
        console.log(error)
    }
}

exports.adminbannerupdate = async (req, res) => {
    try {
        const { title, desc, ldesc } = req.body
        const id = req.params.id
        if (req.file) {
            const filename = req.file.filename
            await Banner.findByIdAndUpdate(id, { title: title, img: filename, desc: desc, ldesc: ldesc })
        } else {
            await Banner.findByIdAndUpdate(id, { title: title, desc: desc, ldesc: ldesc })
        }
        res.redirect('/admin/banner/Banner Update Successfully')
    } catch (error) {
        console.log(error)
    }
}

exports.userbannerdetails = async (req, res) => {
    try {
        const record = await Banner.findOne()
        res.render('banner.ejs', { record })
    } catch (error) {
        console.log(error)
    }
}